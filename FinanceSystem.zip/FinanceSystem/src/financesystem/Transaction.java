/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package financesystem;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import javax.smartcardio.Card;

/**
 *
 * @author epfeffer
 */

public class Transaction implements Serializable {
    
    private static final long serialVersionUID = 7171256429334229014l;
    private int transId;
    private Date startDate;
    private Date endDate;
    private String type;
    private double amount;
    private String description;
    private String paymentMethod;
    private String category;
    private String comment;
    private boolean transPrivate;
    private boolean transFrequency;
    public enum freqType {Daily, Weekly, Monthly};
    private String Tprivate;
    private static int nextTransId=1;
    private Card card;
    private User user;
    private int userId;
    private int groupId;
    
    public static int getNextId() { return nextTransId; }
    public static void setNextId(int i) { nextTransId = i; }
   
    public Transaction() {
        }
    
    public Transaction(Date startDate,Date endDate,double amount,String type, String paymentMethod,String description, String category,String comment,boolean transPrivate){
        this();
        this.startDate = startDate;
        this.endDate = endDate;
        this.amount = amount;
        this.type = type;
        this.paymentMethod = paymentMethod;
        this.description = description;
        this.category = category;
        this.comment = comment;
        this.transPrivate = transPrivate;
       
        if(transPrivate == true) { Tprivate = "Private"; }
        else { Tprivate = "Public"; }
    }
    
    public int getTransId() { return transId; }
    public void setTransId(int transId){ this.transId = transId;}

    public void setStartDate(Date startDate) { this.startDate = startDate; }
    public Date getStartDate() { return startDate; }
    public void setEndDate(Date endDate) { this.endDate = endDate; }
    public Date getEndDate() { return endDate; }
    public void setAmount(double amount) { this.amount = amount; }
    public double getAmount() { return amount; }
    public void setDescription(String desc) { this.description = desc; }
    public String getDescription() { return description; }
    public String getCategory() { return category; }
    public void setCategory(String cat) { this.category = cat; }
    public void setPaymentMethod(String pMeth) { this.paymentMethod = pMeth; }
    public String getPaymentMethod() { return paymentMethod; }
    public void setComment(String comment) { this.comment = comment; }
    public String getComment() { return comment; }
    public void setTransFrequency(boolean tFrq) { this.transFrequency = tFrq; }
    public boolean isTransFrequency() { return transFrequency; }
    public void setTransPrivate(boolean tPriv) { this.transPrivate = tPriv; }
    public boolean isTransPrivate() { return transPrivate; }
    public int getUserId() { return userId; }
    public void setUserId(int userId){this.userId = userId;}
    public int getGroupId() { return groupId; }    
    public void setGroupId(int groupId) {this.groupId = groupId;}
    
    
    
    public static boolean addTransaction(Transaction transaction) {
        if (transaction.amount >= 0.01 && transaction.transId == 0) {
            transaction.setTransId(FinanceSystem.nextTransactionId());
            FinanceSystem.trans.add(transaction);
            FinanceSystem.saveTransactionToFile();
            return true;
        } else { return false; }
    }
 
    public static boolean updateTransaction(Transaction trans){
        for(int i=0; i < FinanceSystem.trans.size(); i++){
            Transaction item = FinanceSystem.trans.get(i);
            
            if(item.getTransId() == trans.getTransId()){
                FinanceSystem.trans.set(i, trans);
                FinanceSystem.saveTransactionToFile();
                return true;
            }
        }
        return false;
        
        
    }
    
    
    public static boolean removeTransaction(int transId){
        for(int i=0; i < FinanceSystem.getTrans().size(); i++){
            Transaction item = FinanceSystem.getTrans().get(i);
            if(item.getTransId()==transId){
                FinanceSystem.getTrans().remove(i);
                FinanceSystem.saveTransactionToFile();
                return true;
            }
        }
        return false;
    }
    
    public static LinkedList<Transaction> listByUserId(int id) {
        LinkedList<Transaction> list = new LinkedList<>();
        for (Transaction trans: FinanceSystem.getTrans()) {
            if (trans.getUserId() == id) {
                list.add(trans);
            }
        }
        return list;
    }
    
    public static ArrayList<Transaction> queryByGroupId(int groupId) {
        ArrayList<Transaction> list = new ArrayList<>();
        for (Transaction trans: FinanceSystem.getTrans()) {
            if (trans.getGroupId()== groupId && !trans.isTransPrivate()) {
                list.add(trans);
            }
        }
        return list;
    }
    
    public static String getPersionMonthlyCategoryReport() {
        LinkedList<Transaction> list = listByUserId(FinanceSystem.loginUser.getUserId());
        return getCategoryReportFromTrans(list);
    }
    
    public static String getCategoryReportFromTrans(LinkedList<Transaction> list) {
        HashMap<String, ArrayList<Transaction>> monthlyMap = new HashMap<>(); 
        ArrayList<Transaction> transs = new ArrayList<Transaction>();
        
        for (Transaction tran : list) {
            // get month
            String yearMonth = DateManagement.getYearMonth(tran.getStartDate());
//            transs = monthlyMap.getOrDefault(tran, new ArrayList<>());
            transs.add(tran);
            monthlyMap.put(yearMonth, transs);
        }
        System.out.print(transs);
        
        StringBuilder sb = new StringBuilder();
        ArrayList<Transaction> trans = new ArrayList<Transaction>();
        
        for (String month : monthlyMap.keySet()) {
            
            for(int i=0; i<transs.size();i++){
 
            if((DateManagement.getYearMonth(transs.get(i).getStartDate())).equals(month)){
            trans.add(transs.get(i));
            }
            }
            double shopping = 0;
            double education = 0;
            double grocery = 0;
            double entertainment = 0;
            double other = 0;
            System.out.println(trans);
            for (Transaction tran : trans) {
                String category = tran.getCategory();
                switch(category) {
                    // Shopping, Education, Grocery, Entertainment, Other
                    case "Shopping":
                        shopping += tran.amount;
                        break;
                    case "Education":
                        education += tran.amount;
                        break;
                    case "Grocery":
                        grocery += tran.amount;
                        break;
                    case "Entertainment":
                        entertainment += tran.amount;
                        break;
                    case "Other":
                        other += tran.amount;
                        break;
                }
            }
            
            String item = month + " Shopping:" + shopping + ", Education:" + education
                    + ", Grocery:" + grocery + ", Entertainment:"
                    + entertainment + ", Other:" + other + "\n";
            sb.append(item);
        }
        
        return sb.toString();
    }
    
    
    @Override
    public String toString() {
        return startDate + "              " + paymentMethod+ "              " + amount + "                  " + category;
    }
}