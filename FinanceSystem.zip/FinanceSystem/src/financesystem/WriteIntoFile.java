/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package financesystem;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author yifeisun
 */
public class WriteIntoFile {
    
    public static void write(File file, String content) {
        FileWriter fw = null;
        try {
          fw = new FileWriter(file);
          fw.write(content);
          fw.close();
        } catch (IOException e) { e.printStackTrace(); }
    }
    
    
}
