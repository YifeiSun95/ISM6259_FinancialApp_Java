/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package financesystem;

import java.io.Serializable;
import java.util.Comparator;
import java.util.LinkedList;

/**
 *
 * @author paaps
 */
public class Group implements Serializable,Comparable<Group> {
   
    private static final long serialVersionUID = -4189003349721468888l;
    
    static void deleteGroup(String gName) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    //Attributes;
    private int groupId;
    private String groupName;
//    private String memberName;
    private String memberEmail;
    private User u;
  //  private static int groupNum=1;
 

  //  private static int countId=101;

    // Get Methods;
    /**
     * @return the groupId
     */
  //  public static int getGroupNum() { return groupNum; }
  //  public static void setGroupNum(int i) { groupNum =i; }

    public int getGroupId() { return groupId; }
    public String getGroupName() { return groupName; }
    public void setGroupName(String newGroupName) { this.groupName = newGroupName; }
    public String getMemberEmail() { return memberEmail;}

    //Constructor;
    public Group(String groupName, String memberEmail)
    {
       this.groupName=groupName;
       this.memberEmail=memberEmail;
       
    }
  
    public static boolean deleteMemberEmail(Group g1){
        for(int i=0; i < FinanceSystem.getGroups().size(); i++){
            Group g = FinanceSystem.getGroups().get(i);
            if(g.getGroupName().equals(g1.groupName) && g.getMemberEmail().equals(g1.getMemberEmail())){
                FinanceSystem.getGroups().remove(i);
                return true;            
            }
        }
        return false;
    }
    
    public static boolean modifyGroup(String gOld, String gNew){
        
        LinkedList<Group> g = FinanceSystem.groups;
        
        for(int i=0; i < g.size(); i++){
            if (g.get(i).getGroupName().equals(gOld)) {
                g.get(i).setGroupName(gNew);
                
            }
            System.out.println("Working: " + gOld + ", " + gNew);
        }
        return false;
 }
    

    public Group() { 
          
    }

    //toString();

    public String toString() {
        return  groupName +"-"+ memberEmail;    
    }

    @Override
    public int compareTo(Group o) {
        int ret=this.groupName.compareTo(o.groupName);
        return ret;
//        if(ret!=0){
//            return ret;
//        }
//        else
//        {
//          ret=this.memberEmail.compareTo(o.memberEmail);
//          return ret;
//        }
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
 class GroupComparatorByMemberEmail implements Comparator<Group>
 {
           public int compare(Group o1, Group o2){
               return (o1.getMemberEmail().compareTo(o2.getMemberEmail()));
           }                                    
}



