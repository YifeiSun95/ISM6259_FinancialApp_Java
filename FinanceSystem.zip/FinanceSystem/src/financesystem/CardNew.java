/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package financesystem;

import java.io.Serializable;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;

/**
 *
 * @author yifeisun
 */
public class CardNew  implements Serializable{
    private static int cardID;
    protected String cardName;
    protected String cardNumber;
    protected Date expDate;
    protected int cardUserID;
    
    
    protected Type cardType;
   
    
    private static int nextCardID=001;

    public  static int getNextId() { return nextCardID; }
    public  int getCardID() { return cardID; }
    public  static void setNextId(int i) { nextCardID = i; }

    public Type getCardType() {
        return cardType;
    }

    public void setCardType(Type cardType) {
        this.cardType = cardType;
    }
    
    
    public CardNew(){cardID = nextCardID; nextCardID++;}
    public CardNew(String cName, String cNumber, Date date){
        this();
        this.cardName = cName;
        this.cardNumber = cNumber;
        this.expDate = date;
    }
    
    public void setCardName(String cardName){this.cardName = cardName;}
    public void setCardNumber(String cardNumber){this.cardNumber = cardNumber;}
    public void setExpDate(Date date){this.expDate = date;}
    public void setCardUserID(int cardUserID){this.cardUserID = cardUserID;}
    
    public static boolean addCard(CardNew card){
        int index = queryIndexByNumber(card.cardNumber);
        if (index == -1) {
            FinanceSystem.cards.add(card);
        } else {
            FinanceSystem.cards.set(index, card);
        }
        FinanceSystem.saveCardToFile();
        return true;
        
    }
   
    
    public String getCardName(){ return cardName;}
    public String getCardNumber(){return cardNumber;}
    public Date getExpDate(){return expDate;}
    public int getCardUserID(){ return cardUserID;}
   
    
    
   
    
    public static CardNew queryByCardNumber(String cardNumber) {
        for (CardNew card : FinanceSystem.cards) {
            if (card.cardNumber.equals(cardNumber)
//                    && card.getCardUserID() == FinanceSystem.loginUser.getUserId()
                    ) {
                return card;
            }
        }
        return null;
    }
    
 
    public static LinkedList<CardNew> queryByCardNumbers(LinkedList<String> cardNumbers) {
        LinkedList<CardNew> cards = new LinkedList<>();
        for (String cardNumber : cardNumbers) {
            CardNew card = queryByCardNumber(cardNumber);
            if (card != null)
                cards.add(card);
        }
        return cards;
    }
    
    public static int queryIndexByNumber(String cardNumber) {
        int i = 0;
        for (CardNew card : FinanceSystem.cards) {
            if (card.cardNumber.equals(cardNumber)) {
                return i;
            }
            i++;
        }
        return -1;
    }
    
    public static boolean removeCardById(int cardId){
        for(int i=0; i < FinanceSystem.getCards().size(); i++){
            CardNew card = FinanceSystem.getCards().get(i);
            if(card.getCardID()==cardId){
                FinanceSystem.getCards().remove(i);
                FinanceSystem.saveCardToFile();
                return true;
            }
        }
        return false;
    }
     
      public static boolean removeCard(String cardDetails) {
        Iterator<CardNew> it = FinanceSystem.cards.iterator();
        while(it.hasNext()) {
            CardNew card = it.next();
            if (card.toString().equals(cardDetails)) {
                it.remove();
                FinanceSystem.saveCardToFile();
                return true;
            }
        }
        return false;
    }
     
    public static enum Type implements Serializable {
        Credit("Credit"), Debit("Debit");
        private String type;

        public String getType(){
            return type; 
        }

        private Type(String type){
            this.type = type;    
        }
    }
    
    
     @Override
    public String toString() {
        return cardName + "    " + cardNumber + "    " + expDate + "    " + cardType + "    ";
    }
    
    
}
    


    

