/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package financesystem;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Locale;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;


/**
 *
 * @author paaps
 */
public class PieChartGUI extends JFrame{
    public PieChartGUI(String title,String chartTitle){
        title = "Finance Management System";
        chartTitle = "Expense Spent on each category";
        PieDataset dataset = createDataSet();
        JFreeChart chart = createChart(dataset,chartTitle);
        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(500, 300));
        setContentPane(chartPanel);
                
    }

    private PieDataset createDataSet(){
        LinkedList<Transaction> transList = FinanceSystem.getTrans();
        int userID = FinanceSystem.loginUser.getUserId();
        ArrayList<String> catList = new ArrayList<>();
        if(transList.isEmpty()) {
            JOptionPane.showMessageDialog(null, "This user does not have any transactions to show.");
        }
                double shoppingAmt =0.00;
                double educAmt =0.00;
                double groceryAmt =0.00;
                double entAmt =0.00;
                double otherAmt =0.00;
        
            for(int i = 0;i<transList.size();i++){
            if(transList.get(i).getUserId()==userID){
                String category=transList.get(i).getCategory();
                
                System.out.println(category);
                switch(category){
                    case "Shopping":
                        shoppingAmt += transList.get(i).getAmount();
                        break;
                    case "Education":
                        educAmt += transList.get(i).getAmount();
                        break;
                    case "Grocery":
                        groceryAmt += transList.get(i).getAmount();
                        break;
                            
                    case "Entertainment":
                        entAmt += transList.get(i).getAmount();
                        break;
                            
                    case "Other":
                        otherAmt += transList.get(i).getAmount();
                        break;
                    default:
                        System.out.println("Nothing to show!");
                        break;
                }   
            
            }
            
            }
            double totalAmt=shoppingAmt+educAmt+groceryAmt+entAmt+otherAmt;
            double PercentShop= (shoppingAmt/totalAmt)*100;
            double PercentEdu= (educAmt/totalAmt)*100;
            double PercentGroc= (groceryAmt/totalAmt)*100;
            double PercentEnt= (entAmt/totalAmt)*100;
            double PercentOth= (otherAmt/totalAmt)*100; 
            DefaultPieDataset result = new  DefaultPieDataset();
            result.setValue("Shopping - "+PercentShop+"%" ,PercentShop);
            result.setValue("Education - "+PercentEdu+"%",PercentEdu);
            result.setValue("Grocery - "+PercentGroc+"%",PercentGroc);
            result.setValue("Entertainment - "+PercentEnt+"%",PercentEnt);
            result.setValue("Other - "+PercentOth+"%",PercentOth);
            
            return result;
    }
 
    private JFreeChart createChart(PieDataset dataset, String title)
       {
         JFreeChart chart = ChartFactory.createPieChart(title, dataset, true, true, false);
         PiePlot plot = (PiePlot) chart.getPlot();
         plot.setStartAngle(0);
         plot.setForegroundAlpha(0.5F);
         
         return chart;
       } 

}
    

