/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package financesystem;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 *
 * @author yifeisun
 */
public class FileIO {
    
    public static boolean saveFile(String key, Serializable obj){
        try{
            ObjectOutputStream o = new ObjectOutputStream(new FileOutputStream(key));
            o.writeObject(obj);
            o.close();
            return true;}
        catch(Exception e){
            System.out.println(e.toString());
            
        }return false;
    }
    
    
    public static Serializable getFile(String key){
        
        File file = new File(key);
        if(!file.exists())
        {return null;}
        try{
            ObjectInputStream in = new ObjectInputStream(new FileInputStream(file));
            Serializable t = (Serializable)in.readObject();
            in.close();
            return t;
            }
            catch(Exception e){ 
            System.out.println(e.toString());
            }
            return null;
        } 
    }



