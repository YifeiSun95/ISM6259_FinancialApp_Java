/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package financesystem;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 *
 * @author yifeisun
 */
public class DateManagement {
    private static final DateFormat dateFormat = new SimpleDateFormat("MM.dd.yyyy", Locale.getDefault());
    private static final DateFormat monthFormat = new SimpleDateFormat("yyyy-MM", Locale.getDefault());
    public static final long DAY_MS = 1000L * 60 * 60 * 24;
    
    public static String getYearMonth(Date date) {
        return monthFormat.format(date);
    }
    
    public static String formatDate(Date date) {
        return dateFormat.format(date);
    }
  
    
}
