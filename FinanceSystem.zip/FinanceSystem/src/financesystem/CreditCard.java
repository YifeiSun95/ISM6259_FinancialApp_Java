/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package financesystem;

/**
 *
 * @author yifeisun
 */
public class CreditCard extends CardNew {
    protected int creditLimit;

    public int getCreditLimit() {
        return creditLimit;
    }

    public void setCreditLimit(int creditLimit) {
        this.creditLimit = creditLimit;
    }

    public CreditCard() {
        cardType = Type.Credit;
    }

    @Override
    public String toString() {
        return super.toString() + "   " + creditLimit;
    }

}
    
    

