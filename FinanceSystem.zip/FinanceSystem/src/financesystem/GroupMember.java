/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package financesystem;

import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedList;

/**
 *
 * @author yifeisun
 */
public class GroupMember implements Serializable {


    private int groupId;
    private int memberId;

    public GroupMember(int groupId, int memberId) {
        this.groupId = groupId;
        this.memberId = memberId;
    }

    public GroupMember() {
    }
    
    public static LinkedList<Group> queryGroupsByMemberId(int memberId) {
        LinkedList<Group> groups = new LinkedList<>();
        for (GroupMember gm : FinanceSystem.groupMembers) {
            if (gm.memberId == memberId) {
             //   groups.add(Group.queryById(gm.groupId));
            }
        }
        return groups;
    }
    
    public static java.util.ArrayList<GroupMember> queryMembersByGroupId(int groupId) {
        java.util.ArrayList<GroupMember> groups = new java.util.ArrayList<>();
        for (GroupMember gm : FinanceSystem.groupMembers) {
            if (gm.groupId == groupId) {
                groups.add(gm);
            }
        }
        return groups;
    }
    
    public static void delete(int groupId, int id) {
        Iterator<GroupMember> it = FinanceSystem.groupMembers.iterator();
        while(it.hasNext()) {
            GroupMember member = it.next();
            if (member.groupId == groupId && member.memberId == id) {
                it.remove();
                break;
            }
        }
    }
    
    public int getGroupId() {
        return groupId;
    }

    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }
    
    
}
