/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package financesystem;

/**
 *
 * @author paaps
 */
public class IndexOutOfBoundException extends Exception {

    /**
     * Creates a new instance of <code>IndexOutOfBoundException</code> without
     * detail message.
     */
    public IndexOutOfBoundException() {
    }

    /**
     * Constructs an instance of <code>IndexOutOfBoundException</code> with the
     * specified detail message.
     *
     * @param msg the detail message.
     */
    public IndexOutOfBoundException(String msg) {
        super(msg);
    }
}
