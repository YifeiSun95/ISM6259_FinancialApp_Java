/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package financesystem; 

import java.util.LinkedList;
import javax.smartcardio.Card;
import javax.swing.JOptionPane;
import java.util.Date;

/**
 *
 * @author epfeffer
 */
public class FinanceSystem {
    public static LinkedList<User> users = new LinkedList<User>();
    public static LinkedList<Transaction> trans = new LinkedList<Transaction>();
    public static LinkedList<CardNew> cards = new LinkedList<CardNew>();
    public static LinkedList<Group> groups = new LinkedList<Group>();
    public static LinkedList<GroupMember> groupMembers = new LinkedList<>();
    public static User loginUser = null;
    
    static {
        users.add(new User(1, "yifei","yifei", "yifei", "yifei", "yifei", "yifei", 1, 1));
        users.add(new User(1, "emily","yifei", "yifei", "yifei", "yifei", "yifei", 1, 1));
        groupMembers.add(new GroupMember(1, 1));
        
    }
    
    // User Methods
    public static void addUser(int id, String name, String phone, String email, String password, String cur, String lang, int not, int sur) {
        if ( searchUsers(email,password) != null ) { JOptionPane.showMessageDialog(null, "User already exists.");
        } else {
            users.add(new User(id,name, phone, email, password, cur, lang, not, sur));
            FinanceSystem.saveUserToFile();
            
        }
    }
    
    public static LinkedList<User> getUsers() { return users; }
    public static void setUsers(LinkedList<User> user) { users = user; }
    
    public static int nextUserId() {
        return users.get(users.size() - 1).getUserId() + 1;
    }
        
    public static User searchUsers(String email, String password) {
        for(int i=0; i < users.size(); i++) {
            if(!password.equals(users.get(i).getPassword()) || !email.equals(users.get(i).getEmail())) { return null; }
            else {
                return users.get(i);
            }
        }
        return null;
    }
    
    // Transaction Methods
    public static void addTransaction(Date startDate,Date endDate,double amount,String type, String paymentMethod,String description, String category,String comment,boolean transPrivate) {
        trans.add(new Transaction(startDate,endDate,amount,type,paymentMethod,description,category,comment,transPrivate));
        FinanceSystem.saveTransactionToFile();
    }
    public static void addTransactions(Transaction transaction) {
        trans.add(transaction);
        FinanceSystem.saveTransactionToFile();
    }
    

    public static LinkedList<Transaction> getTrans() { return trans; }
    public static Transaction searchTransactions(int transId, int userId) {
        for(int i=0; i < trans.size(); i++) {
            if(transId == trans.get(i).getTransId() && userId == trans.get(i).getUserId()) return trans.get(i);
        }
        return null;
    }
    
    
    // Card Methods
//    public static void addCard(String cName, String cNum, Date expDate, boolean cType, int cUserId) {
//        cards.add(new CardNew(cName, cNum, expDate, cType, cUserId));
//        FinanceSystem.saveCardToFile();
//        JOptionPane.showMessageDialog(null, "Card has been added successfully.");
//    }
    public static void addCard(CardNew card) {
        cards.add(card);
        FinanceSystem.saveCardToFile();
    }
    
    public static LinkedList<CardNew> getCards() { return cards; }
    public static void setCards(LinkedList<CardNew> card) { cards = card; }
    
    public static Card searchCards(String cardNum) {
        return null;
    }
    
    //Group Methods

    public static void addToGroup(String groupName, String memberEmail)
         {groups.add(new Group(groupName,memberEmail)) ;
         }

    public static void addGroup(String groupName, String memberEmail) {
        
        
//        for (int i=0; i<groups.size(); i++) {
//            if (groups.get(i).getGroupName().equals(groupName)) { 
//                if (groups.get(i).getMemberEmail().equals(memberEmail)) {
//                    System.out.println("Member already exists for this group.");
//                }
//                else {
//                    System.out.println("Group exists, and email doesn't match.");
//                }
//            }            
////            else {
                groups.add(new Group(groupName, memberEmail));
////                System.out.println("else statement break");
//////                break;
////            }
//            break;
//        }
        
    }
    public static void addGroup(Group group) {
        groups.add(group);
    }
    public static LinkedList<Group> getGroups() { return groups; }
    public static void setGroup(LinkedList<Group> groupl) { groups = groupl; }
    
    public static LinkedList<String> searchGroups(String email) {
        LinkedList<String> list = new LinkedList<String>();
        for(int i=0; i < groups.size(); i++) {
            if(email.equals(groups.get(i).getMemberEmail())) {
                list.add(groups.get(i).getGroupName());
                System.out.println("Group added to list in searchGroups");
//                return list;
            }
        }
        return list;
    }
    
    public static int nextUserGroupId() {
        return groups.get(groups.size() - 1).getGroupId() + 1;
    }
    
    
    
    
    public static void saveTransactionToFile(){
        FileIO.saveFile("Transactions", trans);
    }
    public static void getTransactionFromFile(){
        LinkedList<Transaction> list = (LinkedList<Transaction>) FileIO.getFile("Transactions");
        if(null != list){
            trans = list;
        }
    }
    

    public static void saveUserToFile(){
        FileIO.saveFile("Users", users);
    }
    public static void getUserFromFile(){
        LinkedList<User> list = (LinkedList<User>) FileIO.getFile("Users");
        if(null != list){
            users = list;
        }
    } 
  
    
    public static void saveCardToFile(){
        FileIO.saveFile("Cards", cards);
    }
    public static void getCardFromFile(){
        LinkedList<CardNew> list = (LinkedList<CardNew>) FileIO.getFile("Cards");
        if(null != list){
            cards = list;
        }
    } 
    

    
    
    
    
    public static void loadAllFromFiles() {
    getTransactionFromFile();
    getUserFromFile();
    getCardFromFile();
    }
    
    
    
    public static int nextTransactionId() {
        if (trans.size() == 0) {
            return 1;
        }
        return trans.get(trans.size() - 1).getTransId() + 1;
    }
    
    
    
    
    
    
    
    
    public static void main(String[] args) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HomeGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HomeGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HomeGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HomeGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        String currentUserId = System.getProperty("userId");
        FinanceSystem.loadAllFromFiles();
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoginGUI().setVisible(true);
            }
        });
    }
}