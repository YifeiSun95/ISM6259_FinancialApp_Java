/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package financesystem;  

//import java.io.Serializable;

import java.io.Serializable;
import java.util.LinkedList;


/**
 *
 * @author epfeffer
 */
public class User  implements Serializable {
    
    private static final long serialVersionUID = -8714973756361290828l;
    private int userId;
    private String name;
    private String phone;
    private String email;
    private String password;
    private String currency = "US Dollars";
    private String language = "English";
    private int notifications = 1; // by default, notifications are enabled
    private int surveys = 1; // by default, surveys are enabled
    
    private LinkedList<String> cardsNumbers= new LinkedList<String>();
    private LinkedList<Group> groups= new LinkedList<Group>();
    
   
    

    
    public int getUserId() { return userId; }
    public String getName() { return name; }
    public String getPhone() { return phone; }
    public String getEmail() { return email; }
    public String getPassword() { return password; }
    public String getCurrency() { return currency; }    
    public String getLanguage() { return language; }
    public int getNotificationSetting() { return notifications; }
    public int getSurveySetting() { return surveys; }
    
    public void setUserId(int userId) { this.userId = userId; }
    public void setName(String userName) { this.name = userName;}
    public void setPhone(String userPhone) { this.phone = userPhone; }
    public void setEmail(String userEmail) { this.email = userEmail; }
    public void setPassword(String passWord) { this.password = passWord; }
    public void setCurrency(String currency) { this.currency = currency; }    
    public void setLanguage(String language) { this.language = language; }
   
    
    public String toString() {
        return userId + "," + name + "," + phone + "," + email + "," + currency + "," + language + "," + notifications + "," + surveys;
    }
    
    public User() {  }
    
    public User(int userId,String name, String phone, String email, String password, String currency, String language, int note, int survey) {
        this();
        this.userId = userId;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.password = password;
        this.currency = currency;
        this.language = language;
        this.notifications = note;
        this.surveys = survey;
    }
    
    public static boolean add(User user) {
        if (verifyEmail(user.getEmail())) {
            return false;
        }
        FinanceSystem.users.add(user);
        FinanceSystem.saveUserToFile();
        return true;
    }
    
    public static boolean verifyEmail(String userEmail){
        for (User user : FinanceSystem.users) {
            if (user.getEmail().equals(userEmail)) {
                return true;
            }
        }
        return false;
    }
    
    public static boolean checkLogin(String email, String password) {
        for (User user : FinanceSystem.users) {
            if (user.getEmail().equals(email)) {
                return user.getPassword().equals(password);
            }
        }
        return false;
    }
    
    public static User getUserByEmail(String email) {
        for (User user : FinanceSystem.users) {
            if (user.getEmail().equals(email)) {
                return user;
            }
        }
        return null;
    }
        
    
    
    public boolean addCardNumbers(String cardNumber){
        if(cardsNumbers.contains(cardNumber)){
            return false;

        }else{
            cardsNumbers.add(cardNumber);
            FinanceSystem.saveUserToFile();
            return true;
        }

    }
    
     public LinkedList<String> getCardNumbers() {
        return cardsNumbers;
    }

    public void setCardNumbers(LinkedList<String> cardNumbers) {
        this.cardsNumbers = cardNumbers;
    }
    
    public LinkedList<Group> getGroups(){
        return groups;
    
}
    public void setGroups(LinkedList<Group> groups) {
        this.groups = groups;
    }
}
  